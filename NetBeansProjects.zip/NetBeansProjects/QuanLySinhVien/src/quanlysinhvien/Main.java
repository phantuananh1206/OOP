
package quanlysinhvien;
public class Main {

    public static void main(String[] args) {
     SinhVien sv = new SinhVien();
     sv.NhapTT();
     sv.HienThiTT();
    }
    
}
